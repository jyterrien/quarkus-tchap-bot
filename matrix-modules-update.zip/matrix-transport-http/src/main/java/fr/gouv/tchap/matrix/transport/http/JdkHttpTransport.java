package fr.gouv.tchap.matrix.transport.http;

import fr.gouv.tchap.matrix.exception.MatrixException;
import fr.gouv.tchap.matrix.exception.RateLimitException;
import fr.gouv.tchap.matrix.transport.HttpTransport;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

/**
 * Implémentation HttpTransport basée sur java.net.http.HttpClient (JDK 11+).
 * Remplaçable par une implémentation Vert.x sans toucher au core.
 */
public class JdkHttpTransport implements HttpTransport {

    private final HttpClient httpClient;
    private final String homeserverUrl;

    public JdkHttpTransport(String homeserverUrl) {
        this.homeserverUrl = homeserverUrl.endsWith("/")
            ? homeserverUrl.substring(0, homeserverUrl.length() - 1)
            : homeserverUrl;
        this.httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(30))
            .build();
    }

    @Override
    public CompletionStage<String> get(String path, String accessToken) {
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(homeserverUrl + path))
            .header("Authorization", "Bearer " + accessToken)
            .GET()
            .build();
        return send(request);
    }

    @Override
    public CompletionStage<String> put(String path, String accessToken, String jsonBody) {
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(homeserverUrl + path))
            .header("Authorization", "Bearer " + accessToken)
            .header("Content-Type", "application/json")
            .PUT(HttpRequest.BodyPublishers.ofString(jsonBody))
            .build();
        return send(request);
    }

    private CompletionStage<String> send(HttpRequest request) {
        CompletableFuture<String> result = new CompletableFuture<>();
        httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
            .thenAccept(response -> {
                if (response.statusCode() == 429) {
                    result.completeExceptionally(new RateLimitException("Rate limited", 1000));
                } else if (response.statusCode() >= 400) {
                    result.completeExceptionally(new MatrixException(
                        "HTTP " + response.statusCode() + ": " + response.body()));
                } else {
                    result.complete(response.body());
                }
            })
            .exceptionally(ex -> {
                result.completeExceptionally(ex);
                return null;
            });
        return result;
    }
}

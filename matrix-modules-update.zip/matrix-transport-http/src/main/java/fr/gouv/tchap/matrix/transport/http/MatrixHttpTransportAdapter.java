package fr.gouv.tchap.matrix.transport.http;

import fr.gouv.tchap.matrix.core.transport.MatrixTransport;
import fr.gouv.tchap.matrix.transport.HttpTransport;

import java.util.concurrent.CompletionStage;

/**
 * Pont entre le port interne du core (MatrixTransport)
 * et le contrat public de transport (HttpTransport).
 */
public class MatrixHttpTransportAdapter implements MatrixTransport {

    private final HttpTransport delegate;

    public MatrixHttpTransportAdapter(HttpTransport delegate) {
        this.delegate = delegate;
    }

    @Override
    public CompletionStage<String> get(String path, String accessToken) {
        return delegate.get(path, accessToken);
    }

    @Override
    public CompletionStage<String> put(String path, String accessToken, String jsonBody) {
        return delegate.put(path, accessToken, jsonBody);
    }
}

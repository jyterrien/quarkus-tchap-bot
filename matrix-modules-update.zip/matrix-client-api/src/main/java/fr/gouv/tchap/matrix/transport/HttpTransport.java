package fr.gouv.tchap.matrix.transport;

import java.util.concurrent.CompletionStage;

/**
 * Contrat public de transport HTTP, indépendant de Matrix et de Quarkus.
 * Les implémentations concrètes (JDK, Vert.x) vivent dans matrix-transport-http.
 */
public interface HttpTransport {

    CompletionStage<String> get(String path, String accessToken);

    CompletionStage<String> put(String path, String accessToken, String jsonBody);
}

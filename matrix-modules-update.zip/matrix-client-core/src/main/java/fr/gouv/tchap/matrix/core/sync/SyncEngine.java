package fr.gouv.tchap.matrix.core.sync;

import fr.gouv.tchap.matrix.core.transport.MatrixHttpApi;
import fr.gouv.tchap.matrix.event.MatrixEvent;
import fr.gouv.tchap.matrix.sync.SyncTokenStore;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

public class SyncEngine {

    private final MatrixHttpApi api;
    private final SyncTokenStore tokenStore;
    private final Consumer<MatrixEvent> eventConsumer;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private ScheduledExecutorService executor;
    private volatile String currentToken;

    public SyncEngine(MatrixHttpApi api, SyncTokenStore tokenStore, Consumer<MatrixEvent> eventConsumer) {
        this.api = api;
        this.tokenStore = tokenStore;
        this.eventConsumer = eventConsumer;
    }

    public CompletionStage<Void> start() {
        if (!running.compareAndSet(false, true)) return CompletableFuture.completedFuture(null);
        return tokenStore.load().thenCompose(opt -> {
            currentToken = opt.orElse(null);
            executor = Executors.newSingleThreadScheduledExecutor();
            schedule(0);
            return CompletableFuture.completedFuture(null);
        });
    }

    public CompletionStage<Void> stop() {
        running.set(false);
        if (executor != null) executor.shutdownNow();
        return CompletableFuture.completedFuture(null);
    }

    private void schedule(long delayMs) {
        if (running.get()) executor.schedule(this::doSync, delayMs, TimeUnit.MILLISECONDS);
    }

    private void doSync() {
        if (!running.get()) return;
        api.sync(currentToken, 30_000)
            .thenAccept(response -> {
                String nextBatch = extractField(response, "next_batch");
                if (nextBatch != null && !nextBatch.isBlank()) {
                    currentToken = nextBatch;
                    tokenStore.save(nextBatch);
                }
                // TODO Jackson : parser rooms.join.*.timeline.events -> eventConsumer.accept(...)
                schedule(0);
            })
            .exceptionally(ex -> {
                schedule(5_000);
                return null;
            });
    }

    private String extractField(String json, String field) {
        String pattern = "\"" + field + "\":\"";
        int start = json.indexOf(pattern);
        if (start < 0) return null;
        start += pattern.length();
        int end = json.indexOf("\"", start);
        return json.substring(start, end);
    }

    public boolean isRunning() { return running.get(); }
}

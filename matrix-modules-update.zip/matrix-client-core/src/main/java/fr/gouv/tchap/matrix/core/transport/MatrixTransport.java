package fr.gouv.tchap.matrix.core.transport;

import java.util.concurrent.CompletionStage;

/**
 * Port interne du core vers un transport HTTP.
 * Implémenté par matrix-transport-http via MatrixHttpTransportAdapter.
 * Ne fait pas partie du contrat public exposé aux développeurs de bots.
 */
public interface MatrixTransport {

    CompletionStage<String> get(String path, String accessToken);

    CompletionStage<String> put(String path, String accessToken, String jsonBody);
}
